<script lang="ts">
	import type { Stats } from 'src/types/Stats';
	export let data: Stats;

	/*
	
<dl>
	<dt>Rotation Time</dt>
	<dd>{data.rotation}</dd>

	<dt>Revolution Time</dt>
	<dd>{data.revolution}</dd>

	<dt>Radius</dt>
	<dd>{data.radius}</dd>

	<dt>Average Temp.</dt>
	<dd>{data.temperature}</dd>
</dl>
	*/
</script>

<div class="statsBox">
	<div>
		<dl>
			<dt>Rotation Time</dt>
			<dd>{data.rotation}</dd>
		</dl>
	</div>

	<div>
		<dl>
			<dt>Revolution Time</dt>
			<dd>{data.revolution}</dd>
		</dl>
	</div>
	<div>
		<dl>
			<dt>Radius</dt>
			<dd>{data.radius}</dd>
		</dl>
	</div>
	<div>
		<dl>
			<dt>Average Temp.</dt>
			<dd>{data.temperature}</dd>
		</dl>
	</div>
</div>

<style lang="scss">
	@media screen and (min-width: 768px) {
		.statsBox {
			flex-direction: row;
		}
	}

	@media screen and (max-width: 767px) {
		.statsBox {
			flex-direction: column;
		}
	}

	@media screen and (min-width: 421px) {
		.statsBox {
			dl {
				flex-direction: column;
			}
		}
	}

	@media screen and (max-width: 767px) {
		.statsBox {
			dl {
				flex-direction: row;
				justify-content: space-between;
				width: 100%;
			}
			dd {
				text-align: right;
			}
		}
	}

	.statsBox {
		display: flex;
		gap: var(--size-fluid-2);

		div {
			display: flex;
			flex-basis: 100%;
			padding: var(--size-fluid-2);
			border: var(--border-size-1) solid var(--gray-3);
		}

		dl {
			display: flex;
			align-items: stretch;
			gap: var(--size-fluid-2);
		}
	}
</style>
