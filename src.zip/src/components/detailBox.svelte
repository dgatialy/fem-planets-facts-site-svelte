<script lang="ts">
	import type { PlanetContent, Images, Planet } from 'src/types/Planet';

	enum Status {
		Overview = 'overview',
		Structure = 'structure',
		Geology = 'geology'
	}

	export let planet: Planet;
	let current: Status = Status.Overview;
	$: content = planet[`${current}`];
	let image = planet.images.planet;
</script>

<div class="detailBox">
	<div class="descriptionRight_top">
		<button
			class:selected={current === Status.Overview}
			on:click={() => {
				current = Status.Overview;
				image = planet.images.planet;
			}}><span>01</span>Overview</button
		>

		<button
			class:selected={current === Status.Structure}
			on:click={() => {
				current = Status.Structure;
				image = planet.images.internal;
			}}><span>02</span>Structure</button
		>

		<button
			class:selected={current === Status.Geology}
			on:click={() => {
				current = Status.Geology;
				image = planet.images.geology;
			}}><span>03</span>Geology</button
		>
	</div>

	<div class="image">
		{image}
	</div>
	<div class="description">
		<div class="descriptionLeft">
			<h1>{planet.name}</h1>

			<p>{content.content}</p>
			<small>Source: {content.source}</small>
		</div>
		<div class="descriptionRight">
			<button
				class:selected={current === Status.Overview}
				on:click={() => {
					current = Status.Overview;
					image = planet.images.planet;
				}}><span>01</span>Overview</button
			>

			<button
				class:selected={current === Status.Structure}
				on:click={() => {
					current = Status.Structure;
					image = planet.images.internal;
				}}><span>02</span>Structure</button
			>

			<button
				class:selected={current === Status.Geology}
				on:click={() => {
					current = Status.Geology;
					image = planet.images.geology;
				}}><span>03</span>Geology</button
			>
		</div>
	</div>
</div>

<style lang="scss">
	@media screen and (max-width: 786px) {
		.detailBox {
			flex-direction: column;
		}
	}

	@media screen and (min-width: 786px) {
		.description {
			display: flex;
			flex-direction: column;
		}
	}

	@media screen and (max-width: 500px) and (orientation: portrait) {
		.descriptionRight {
			display: none;
		}
	}

	.descriptionRight {
		display: flex;
		flex-direction: column;
		gap: var(--size-fluid-1);

		button {

			padding: var(--size-3) var(--size-5);
			background: none;
			border-width: var(--border-size-1);

			&.selected {
				background-color: #ff3e00;
				color: white;
			}

			span {
				margin-right: var(--size-fluid-1);
			}
		}
	}

	.detailBox {
		display: flex;
		justify-content: space-between;
		gap: var(--size-fluid-4);

		.description {
			display: flex;
			flex-direction: row;
			gap: var(--size-fluid-4);

			.descriptionLeft {
				display: flex;
				flex-direction: column;
				gap: var(--size-fluid-2);
			}
		}
	}

	@media screen and (min-width: 500px) {
		.descriptionRight_top {
			display: none;
		}
	}

	@media screen and (max-width: 500px) {
		.descriptionRight_top {
			display: flex;
		}
	}
</style>
